package com.example.calculadorarandal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Spinner operaciones;
    private LinearLayout suma;
    private LinearLayout fibonacci;
    private LinearLayout calcular;
    private LinearLayout resultado;
    private Button Aceptar;
    private EditText numero1;
    private EditText numero2;
    private EditText tResult;
    private EditText facfib;
    private ImageView signo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        operaciones = findViewById(R.id.operaciones);
        suma = findViewById(R.id.suma);
        fibonacci = findViewById(R.id.fibonacci);
        calcular = findViewById(R.id.calcular);
        resultado = findViewById(R.id.resultado);
        numero1 = findViewById(R.id.numero1);
        numero2 = findViewById(R.id.numero2);
        facfib = findViewById(R.id.facfib);
        tResult = findViewById(R.id.tResult);
        signo = findViewById(R.id.signo);
        Aceptar = findViewById(R.id.Aceptar);

        String[] a = new String[]{"Seleccione una opcion","Suma","Resta","Serie fibonacci","Factorial"};
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1, a);
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        operaciones.setAdapter(adaptador);
        operaciones.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try{
                    switch (position) {
                        case 0:
                            suma.setVisibility(View.GONE);
                            fibonacci.setVisibility(View.GONE);
                            calcular.setVisibility(View.GONE);
                            resultado.setVisibility(View.GONE);
                            numero1.setText("");
                            numero2.setText("");
                            tResult.setText("");

                            break;
                        case 1:
                            suma.setVisibility(View.VISIBLE);
                            calcular.setVisibility(View.VISIBLE);
                            resultado.setVisibility(View.VISIBLE);
                            fibonacci.setVisibility(View.GONE);
                            signo.setImageResource(R.drawable.mas);
                            numero1.setText("");
                            numero2.setText("");
                            tResult.setText("");

                            Aceptar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String val1 = numero1.getText().toString();
                                    String val2 = numero2.getText().toString();
                                    if (!val1.equals("") && !val2.equals("")) {
                                        int va1 = Integer.parseInt(val1);
                                        int va2 = Integer.parseInt(val2);
                                        int r1 = va1 + va2;
                                        tResult.setText("" + r1);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Algún campo esta vacio", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                            break;
                        case 2:
                            suma.setVisibility(View.VISIBLE);
                            calcular.setVisibility(View.VISIBLE);
                            resultado.setVisibility(View.VISIBLE);
                            fibonacci.setVisibility(View.GONE);
                            signo.setImageResource(R.drawable.menos);
                            numero1.setText("");
                            numero2.setText("");
                            tResult.setText("");
                            Aceptar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String val1 = numero1.getText().toString();
                                    String val2 = numero2.getText().toString();
                                    if (!val1.equals("") && !val2.equals("")) {
                                        int va1 = Integer.parseInt(val1);
                                        int va2 = Integer.parseInt(val2);
                                        int r1 = va1 - va2;
                                        tResult.setText("" + r1);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Algún campo esta vacio", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                            break;

                        case 3:
                            fibonacci.setVisibility(View.VISIBLE);
                            calcular.setVisibility(View.VISIBLE);
                            resultado.setVisibility(View.VISIBLE);
                            suma.setVisibility(View.GONE);
                            facfib.setCompoundDrawablesWithIntrinsicBounds(R.drawable.fibonacci, 0, 0, 0);
                            facfib.setText("");
                            tResult.setText("");
                            Aceptar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String fact = facfib.getText().toString();
                                    if (!fact.equals("")) {
                                        int factoria = Integer.parseInt(fact);
                                        int dato1 = 0;
                                        int dato2 = 1;
                                        String resultado = dato1 + ", ";
                                        for (int i = 2; i <= factoria; i++) {
                                            if (i == factoria) {
                                                resultado += dato2;
                                            } else {
                                                resultado += dato2 + ", ";
                                            }
                                            dato2 = dato1 + dato2;
                                            dato1 = dato2 - dato1;
                                        }
                                        tResult.setText(resultado);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Algún campo esta vacios", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                            break;

                        case 4:
                            fibonacci.setVisibility(View.VISIBLE);
                            calcular.setVisibility(View.VISIBLE);
                            resultado.setVisibility(View.VISIBLE);
                            suma.setVisibility(View.GONE);
                            facfib.setCompoundDrawablesWithIntrinsicBounds(R.drawable.factorial, 0, 0, 0);
                            facfib.setText("");
                            tResult.setText("");

                            Aceptar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String fact = facfib.getText().toString();
                                    if (!fact.equals("")) {
                                        int facto = Integer.parseInt(fact);
                                        long factorial = 1;
                                        for (int i = facto; i > 0; i--) {
                                            factorial = factorial * i;
                                        }
                                        tResult.setText(""+ factorial);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Algún campo esta vacio", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                            break;
                    }
                }catch(Exception e){
                    Toast.makeText(getApplicationContext(), "Algún campo esta vacio", Toast.LENGTH_LONG).show();
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(), "No has elegido ninguna opcion", Toast.LENGTH_LONG).show();

            }
        });
    }
}
